<html>
<head>
<title>Frames Test</title>

	<script>
	/*
	 Milonic DHTML Website Navigation Menu - Version 3.4
	 Written by Andy Woolley - Copyright 2002 (c) Milonic Solutions Limited. All Rights Reserved.
	 Please visit http://www.milonic.co.uk/menu or e-mail menu3@milonic.com for more information.
	 
	 The Free use of this menu is only available to Non-Profit, Educational & Personal web sites.
	 Commercial and Corporate licenses  are available for use on all other web sites & Intranets.
	 All Copyright notices MUST remain in place at ALL times and, please keep us informed of your 
	 intentions to use the menu and send us your URL.
	*/
	</script>
	<script language=JavaScript src="frames_body_array.js" type=text/javascript></script>
	<script language=JavaScript src="mmenu.js" type=text/javascript></script>    

</head>
<body bgcolor="#ffffff">  
<font face="helvetica">  
<b>Frames Demo</b><br><br>
<b>File loaded: </b>
<script>
tpar=self.location.href.split("tp=");
document.write(tpar[1])
</script>
<br><br>


    
</body>

</html>
