<?
#-------------------------------------------------------------------------------
# INSTACIA de DESARROLLO
#-------------------------------------------------------------------------------

    $instancia["desarrollo"][apex_db_motor] = "postgres7";
    $instancia["desarrollo"][apex_db_profile] = "192.168.0.1";
    $instancia["desarrollo"][apex_db_usuario] = "dba";
    $instancia["desarrollo"][apex_db_clave] = "xi11dba";
    $instancia["desarrollo"][apex_db_base] = "toba";

#-------------------------------------------------------------------------------
# INSTACIA de PRUEBAS
#-------------------------------------------------------------------------------

    $instancia["prueba"][apex_db_motor] = "postgres7";
    $instancia["prueba"][apex_db_profile] = "127.0.0.1";
    $instancia["prueba"][apex_db_usuario] = "dba";
    $instancia["prueba"][apex_db_clave] = "*dba-";
    $instancia["prueba"][apex_db_base] = "prueba";

#-------------------------------------------------------------------------------
# INSTACIA de PRODUCCION
#-------------------------------------------------------------------------------

    $instancia["produccion"][apex_db_motor] = "postgres7";
    $instancia["produccion"][apex_db_profile] = "127.0.0.1";
    $instancia["produccion"][apex_db_usuario] = "dba";
    $instancia["produccion"][apex_db_clave] = "*dba-";
    $instancia["produccion"][apex_db_base] = "wichi";
  
#-------------------------------------------------------------------------------
# Constantes comunes a todas las intacias
#-------------------------------------------------------------------------------
define("apex_clave_get","x6B2AHNQRqUW9");//Parametros opacos por GET
define("apex_clave_db","dQFpBmBTJFF+By");//Informacion opaca en la base
#-------------------------------------------------------------------------------
?>