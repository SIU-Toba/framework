
-----------  apex_sesion_browser  ------------------------

INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('376','juan','bahia','2004-07-18 06:55:23','2004-07-18 06:55:23',NULL,'c830e2aa1f51179f6df3977abe2fd250','192.168.0.10',NULL);
