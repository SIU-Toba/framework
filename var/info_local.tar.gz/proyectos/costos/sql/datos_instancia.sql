
-----------  apex_usuario_proyecto  ------------------------

INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','ale','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','amcp','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','anonimo','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','ariel','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','arielj','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','ccarolin','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','Cdomina','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','dario','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','edith','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','emiliano','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','eugenio','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','gabriela','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','gdiloret','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','gdiorio','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','gropolo','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','guille','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','hcarball','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','hernan','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','irosati','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','isabel','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','javier','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','jbellia','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','juan','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','leo','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','lujan','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','mariano','coordinador','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','mrossi','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','osmar','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','otesta','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','paula','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','rab','basico','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','ricardo','coordinador','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('costos','santiago','basico','no');

-----------  apex_solicitud  ------------------------

INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8449','browser','costos','/tablas_maestras/anios',NULL,'2004-07-07 02:32:52','0.355257987976');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8450','browser','costos','/tablas_maestras/anios',NULL,'2004-07-07 02:34:54','0.367370128632');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8451','browser','costos','/tablas_maestras/anios',NULL,'2004-07-07 02:34:55','0.352314949036');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8452','browser','costos','/tablas_maestras/semanas',NULL,'2004-07-07 02:35:06','0.347960948944');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9494','browser','costos','/estadisticas/consultores_x_proyecto',NULL,'2004-07-08 16:53:35','0.588404893875');

-----------  apex_sesion_browser  ------------------------

INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('296','juan','costos','2004-07-07 02:29:56','2004-07-07 02:35:41',NULL,'92ec613fe92001ca25a29a27918c4fea','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('320','juan','costos','2004-07-08 14:52:52','2004-07-08 15:05:58',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('323','juan','costos','2004-07-08 15:18:49','2004-07-08 15:32:50',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('325','dario','costos','2004-07-08 15:22:17','2004-07-08 15:49:54',NULL,'bd4d5e0c3e28e9b15b45545f8cf79109','168.83.60.173',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('328','juan','costos','2004-07-08 15:51:58','2004-07-08 16:00:59',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('330','juan','costos','2004-07-08 16:01:34','2004-07-08 16:59:51',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);

-----------  apex_solicitud_browser  ------------------------

INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8449','296','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8450','296','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8451','296','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8452','296','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('9494','330','127.0.0.1');

-----------  apex_solicitud_cronometro  ------------------------

INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.041');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','2','nucleo','SESION: Controlar STATUS SESION','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','3','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','5','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','6','nucleo','SOLICITUD BROWSER: Inicializacion (ZONA, VINCULADOR)','0.04');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','7','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','8','nucleo','SOLICITUD: Cargar info OBJETOS','0.017');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','9','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','10','nucleo','SOLICITUD BROWSER: Pagina TIPO (cabecera) ','0.016');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','11','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','12','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','13','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','14','nucleo','SOLICITUD: Crear OBJETO [463]','0.28');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','15','nucleo','basura','0.006');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','16','objeto','basura','0.024');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','17','objeto','OBJETO HOJA [Array] : Cargar DEFINICION','0.034');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','18','nucleo','SOLICITUD: Crear OBJETO [462]','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','19','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','20','nucleo','SOLICITUD BROWSER: Pagina TIPO (pie) ','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9494','21','nucleo','SOLICITUD: Fin del registro','0');

-----------  apex_solicitud_obj_observacion  ------------------------

INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('89','error','8449','costos','333','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT anio FROM costos_anios; - [ERROR] ERROR:  relation \"costos_anios\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('90','error','8450','costos','333','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT anio FROM costos_anios; - [ERROR] ERROR:  relation \"costos_anios\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('91','error','8451','costos','333','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT anio FROM costos_anios; - [ERROR] ERROR:  relation \"costos_anios\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('92','error','8452','costos','329','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT semana, nombre FROM costos_semanas; - [ERROR] ERROR:  relation \"costos_semanas\" does not exist
');
