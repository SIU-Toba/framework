
-----------  apex_usuario_proyecto  ------------------------

INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','anonimo','externo','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','dario','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','emiliano','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','isabel','coordinador','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','juan','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('eventos','leo','admin','no');

-----------  apex_sesion_browser  ------------------------

INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('295','juan','eventos','2004-07-07 02:26:31','2004-07-07 02:29:56',NULL,'92ec613fe92001ca25a29a27918c4fea','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('338','juan','eventos','2004-07-09 16:25:29','2004-07-09 16:26:08','Cambio de punto de acceso: e:/toba/www/aplicacion.php -> e:/toba/www/admin.php','39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('342','juan','eventos','2004-07-09 16:30:25',NULL,NULL,'83d2e2d17bec39775a82ffbfb769f773','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('341','juan','eventos','2004-07-09 16:29:31','2004-07-09 16:44:41',NULL,'39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('361','juan','eventos','2004-07-14 19:02:48','2004-07-14 19:06:49','Cambio de punto de acceso: f:/toba/www/admin.php -> f:/toba/proyectos/eventos/www/aplicacion.php','ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('362','juan','eventos','2004-07-14 19:06:53','2004-07-14 19:13:34','Cambio de punto de acceso: f:/toba/proyectos/eventos/www/aplicacion.php -> f:/toba/proyectos/eventos/www/admin.php','ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('363','juan','eventos','2004-07-14 19:13:37','2004-07-14 19:13:46','Cambio de punto de acceso: f:/toba/proyectos/eventos/www/admin.php -> f:/toba/proyectos/eventos/www/aplicacion.php','ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('364','juan','eventos','2004-07-14 19:13:49',NULL,NULL,'ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('367','juan','eventos','2004-07-15 02:19:30','2004-07-15 02:19:38',NULL,'87369859ff03165510e2dfed22c16d68','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('373','juan','eventos','2004-07-16 15:37:19',NULL,NULL,'7c791c18cf43b0c41cdebf0494935540','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('375','juan','eventos','2004-07-18 06:24:10','2004-07-18 06:55:23',NULL,'c830e2aa1f51179f6df3977abe2fd250','192.168.0.10',NULL);
