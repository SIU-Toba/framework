
-----------  apex_usuario  ------------------------

INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('hernan','hernan','Hernan Cobo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('javier','javier','Javier Sueyro',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('ariel','ariel','Ariel Zoia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('paula','paula','Paula Senhor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('osmar','osmar','Osmar Madsen',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('isabel','isa','Isabel Pinieyro',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('mariano','mariano','Mariano Menendez',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('guille','guille','Guillermo Trutner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('eugenio','eugenio','Eugenio Bellia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('irosati','irosati','Rosati Isabel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('gabriela','gabriela','Romero Gabriela',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('hcarball','hcarball','Carballo Hern�n J.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('ale','ale','Del� Alejandro',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('jbellia','jbellia','Bellia Javier',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('amcp','amcp','Canedo Per� Ana Maria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('gropolo','gropolo','Ropolo Gabriel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('lujan','lujan','Gurmendi Mar�a de Luj�n',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('rab','rab','Biagiola Rodolfo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('mrossi','mrossi','Rossi Marcela',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('otesta','otesta','Testa Oscar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('Cdomina','Cdomina','D�mina Cecilia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('arielj','arielj','Jerez Ariel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('gdiloret','gdiloret','Di Loreto Guillermo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('gdiorio','gdiorio','Diorio Guillermo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('ccarolin','ccarolin','Carolina Creichmon',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('ricardo','ricardo','Williams Ricardo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('santiago','santiago','Santiago Lima',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('juan','juan','Juan Bordon',NULL,NULL,NULL,NULL,NULL,NULL,'2004-10-22','127',NULL,NULL,'',NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('dario','dario','Dario Spagnuolo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('emiliano','emi','Emiliano Marmonti',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('leo','leo','Leonardo Ramirez',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,'',NULL,NULL,NULL,NULL);
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('anonimo','a','Usuario Anonimo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,'','0',NULL,NULL,'desarrollo...');
INSERT INTO apex_usuario (usuario, clave, nombre, usuario_tipodoc, pre, ciu, suf, email, telefono, vencimiento, dias, hora_entrada, hora_salida, ip_permitida, solicitud_registrar, solicitud_obs_tipo_proyecto, solicitud_obs_tipo, solicitud_observacion) VALUES ('edith','edith','Edith Tejerina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

-----------  apex_usuario_proyecto  ------------------------

INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','anonimo','externo','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','dario','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','edith','documentador','perfil_x');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','juan','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','leo','admin','no');
INSERT INTO apex_usuario_proyecto (proyecto, usuario, usuario_grupo_acc, usuario_perfil_datos) VALUES ('toba','santiago','admin','no');

-----------  apex_solicitud  ------------------------

INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7261','browser','toba','/actividad/control_consola',NULL,'2004-07-06 10:54:46','0.484412908554');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7296','consola','toba','/consola/dump',NULL,'2004-07-06 11:01:33','1.76049804688');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7324','wddx','toba','/red/echo',NULL,'2004-07-06 11:03:19','0.160535097122');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7342','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:17:03','0.461866140366');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7361','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:27:56','0.387646198273');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7364','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:28:04','0.37202000618');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7367','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:28:11','0.377938985825');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7372','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:35','1.66548395157');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7374','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:44','3.07739114761');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7375','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:48','1.19751000404');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7376','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:51','1.24186992645');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7377','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:54','1.29947400093');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7378','consola','toba','/consola/dump',NULL,'2004-07-06 11:28:58','1.199021101');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7391','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:29:42','0.390452861786');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7418','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:32:09','0.458019018173');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7420','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:32:19','0.408629894257');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7423','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:32:25','0.467184066772');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7425','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:32:48','0.461791992188');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7427','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:32:52','0.451951026917');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7432','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:33:41','0.493880987167');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7463','browser','toba','/actividad/control_consola',NULL,'2004-07-06 11:41:54','0.479915142059');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7470','wddx','toba','/red/echo',NULL,'2004-07-06 11:43:31','0.120172977448');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7480','wddx','toba','/red/echo',NULL,'2004-07-06 11:47:20','0.117991924286');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7481','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:47:25','0.582550048828');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7486','browser','toba','/actividad/solicitudes_wddx',NULL,'2004-07-06 11:47:52','0.417005062103');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7495','wddx','toba','/red/echo',NULL,'2004-07-06 11:49:07','0.116409063339');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7497','wddx','toba','/red/echo',NULL,'2004-07-06 11:49:08','0.342040061951');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('7499','browser','toba','/actividad/sesiones',NULL,'2004-07-06 11:49:14','0.427294015884');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8124','browser','toba','/actividad/control_consola',NULL,'2004-07-06 14:07:29','0.526824951172');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8125','consola','toba','/consola/dump',NULL,'2004-07-06 14:09:29','1.4764521122');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8156','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:23:21','0.533129930496');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8171','browser','toba','/actividad/control_consola',NULL,'2004-07-06 14:30:23','0.594326019287');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8202','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:35:54','0.834995985031');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8215','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:39:47','0.722495794296');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8219','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:41:02','9.83004212379');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8221','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:41:18','0.699429988861');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8223','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:41:36','0.948570013046');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8228','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:42:14','2.31656599045');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8231','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:42:46','0.706608057022');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8232','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:44:05','1.1637070179');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8233','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:44:20','0.943935871124');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8234','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:44:45','9.51658987999');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8235','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:44:58','0.403995037079');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8237','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:45:22','0.943750858307');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8239','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:46:14','0.652614116669');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8242','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:47:31','0.372715950012');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8243','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:47:45','0.939157009125');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8245','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:48:32','1.03980493546');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8249','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:52:08','0.905225992203');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8250','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:52:11','0.93780207634');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8251','consola','toba','/consola/info_sql',NULL,'2004-07-06 14:59:50','1.33830881119');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8252','consola','toba','/consola/info_sql',NULL,'2004-07-06 15:03:07','1.17986512184');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8256','consola','toba','/consola/info_sql',NULL,'2004-07-06 15:06:31','1.19283103943');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8261','consola','toba','/consola/info_sql',NULL,'2004-07-06 15:15:14','1.23238897324');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8633','consola','toba','/consola/dump',NULL,'2004-07-06 17:38:44','3.37728500366');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8634','consola','toba','/consola/dump',NULL,'2004-07-06 17:38:48','1.2067360878');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8635','consola','toba','/consola/dump',NULL,'2004-07-06 17:38:52','1.24959015846');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8636','consola','toba','/consola/dump',NULL,'2004-07-06 17:38:55','1.29271316528');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8638','consola','toba','/consola/dump',NULL,'2004-07-06 17:38:58','1.19494199753');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8327','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-07 02:14:53','0.303336858749');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8330','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-07 02:15:05','0.29487991333');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8531','browser','toba','/actividad/control_consola',NULL,'2004-07-07 02:43:42','0.288287162781');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8551','browser','toba','/actividad/control_consola',NULL,'2004-07-07 02:51:09','0.284504890442');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8691','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-07 11:53:46','0.367638111115');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8788','consola','toba','/consola/info_sql',NULL,'2004-07-07 23:34:09','1.05125284195');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8796','consola','toba','/consola/dump',NULL,'2004-07-07 23:35:04','17.7985110283');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8797','consola','toba','/consola/dump',NULL,'2004-07-07 23:35:09','3.89437699318');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8798','consola','toba','/consola/dump',NULL,'2004-07-07 23:35:15','3.57852602005');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8799','consola','toba','/consola/info_sql',NULL,'2004-07-07 23:37:22','1.84043884277');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8808','consola','toba','/consola/dump',NULL,'2004-07-07 23:38:16','22.4317259789');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8809','consola','toba','/consola/dump',NULL,'2004-07-07 23:38:19','0.675778865814');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8810','consola','toba','/consola/info_sql',NULL,'2004-07-07 23:38:52','0.681202888489');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8811','consola','toba','/consola/dump',NULL,'2004-07-07 23:39:51','47.0560560226');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8812','consola','toba','/consola/dump',NULL,'2004-07-07 23:39:57','3.98967909813');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8813','consola','toba','/consola/dump',NULL,'2004-07-07 23:40:04','5.8396821022');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8814','consola','toba','/consola/dump',NULL,'2004-07-07 23:40:14','8.14996504784');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8815','consola','toba','/consola/dump',NULL,'2004-07-07 23:40:19','4.10554599762');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('8884','browser','toba','/admin/objetos/editores/abms',NULL,'2004-07-08 01:33:17','4.24339008331');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9511','browser','toba','/admin/inicio',NULL,'2004-07-08 17:00:42','0.378003835678');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9651','consola','toba','/consola/dump',NULL,'2004-07-08 17:27:21','3.79271316528');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9653','consola','toba','/consola/dump',NULL,'2004-07-08 17:27:24','1.43865299225');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9655','consola','toba','/consola/dump',NULL,'2004-07-08 17:27:28','1.59892892838');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9657','consola','toba','/consola/dump',NULL,'2004-07-08 17:27:31','1.35107803345');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9658','consola','toba','/consola/dump',NULL,'2004-07-08 17:27:34','1.20766091347');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9726','browser','toba','/actividad/solicitudes_wddx',NULL,'2004-07-08 17:56:58','0.322302103043');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('9727','browser','toba','/actividad/solicitudes_wddx',NULL,'2004-07-08 17:57:12','0.291831970215');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10065','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-12 18:14:13','0.448703050613');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10426','browser','toba','/admin/objetos/instanciadores/lista',NULL,'2004-07-13 05:23:56','0.249109983444');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10442','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-13 05:27:26','0.258576869965');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10445','browser','toba','/admin/objetos/instanciadores/cuadro',NULL,'2004-07-13 05:27:45','0.221259117126');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10550','browser','toba','/admin/usuarios/perfil',NULL,'2004-07-14 04:39:28','0.352213144302');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10563','browser','toba','/admin/usuarios/perfil',NULL,'2004-07-14 04:40:51','0.329468011856');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10655','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:16:03','0.232124090195');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10657','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:16:34','0.229449987411');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10663','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:18:03','0.235777854919');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10672','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:19:06','0.243021965027');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10674','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:19:21','0.23343205452');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10696','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:21:10','0.241963863373');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10698','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:21:16','0.257968902588');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10701','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:22:19','0.228559970856');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10715','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:24:48','0.24662899971');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10764','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:38:03','0.230569124222');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10790','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:53:18','0.235110044479');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10796','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:54:31','0.252278089523');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10799','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:54:46','0.25074005127');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10801','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:55:14','0.253505945206');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10808','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 05:55:29','0.253908157349');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10834','browser','toba','/admin/objetos/propiedades',NULL,'2004-07-14 06:09:01','0.239655017853');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10843','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:16:06','0.228044033051');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10852','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:17:01','0.240135908127');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10856','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:17:16','0.249843835831');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10858','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:17:22','0.239055871964');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10861','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:17:40','0.244876861572');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10879','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:25:05','0.242259025574');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10886','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:26:02','0.239497900009');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('10905','browser','toba','/admin/dimensiones/propiedades',NULL,'2004-07-14 06:31:18','0.233657121658');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11105','consola','toba','/consola/info_sql',NULL,'2004-07-14 17:01:17','1.54374504089');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11132','consola','toba','/consola/info_sql',NULL,'2004-07-16 04:00:54','0.983273029327');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11141','consola','toba','/consola/dump',NULL,'2004-07-16 04:02:59','6.51667308807');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11142','consola','toba','/consola/dump',NULL,'2004-07-16 04:03:03','1.32287406921');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11143','consola','toba','/consola/dump',NULL,'2004-07-16 04:03:07','1.29423594475');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11144','consola','toba','/consola/dump',NULL,'2004-07-16 04:03:10','1.30810213089');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11145','consola','toba','/consola/dump',NULL,'2004-07-16 04:03:14','1.19788098335');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11146','consola','toba','/consola/info_sql',NULL,'2004-07-16 04:20:44','1.25514793396');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11155','consola','toba','/consola/dump',NULL,'2004-07-16 04:22:38','4.31762599945');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11156','consola','toba','/consola/dump',NULL,'2004-07-16 04:22:41','1.02349686623');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11157','consola','toba','/consola/dump',NULL,'2004-07-16 04:22:59','1.04693007469');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11158','consola','toba','/consola/dump',NULL,'2004-07-16 04:23:02','1.01014494896');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11159','consola','toba','/consola/dump',NULL,'2004-07-16 04:23:05','0.947355031967');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11160','consola','toba','/consola/dump',NULL,'2004-07-16 04:23:33','3.18632102013');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11161','consola','toba','/consola/dump',NULL,'2004-07-16 04:32:52','2.5458240509');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11162','consola','toba','/consola/dump',NULL,'2004-07-16 04:32:57','3.26636195183');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11163','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:01','1.20159912109');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11164','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:03','1.24875688553');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11165','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:07','1.3132750988');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11166','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:09','1.30778312683');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11167','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:12','1.33297991753');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11168','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:15','1.3172211647');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11169','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:18','1.15219902992');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11170','consola','toba','/consola/dump',NULL,'2004-07-16 04:33:21','1.2080411911');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11171','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:06','2.59954690933');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11172','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:09','0.850792884827');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11173','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:12','1.17533588409');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11174','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:14','0.46718788147');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11175','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:17','1.20020985603');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11176','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:19','0.48642706871');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11177','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:22','1.22512412071');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11178','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:24','0.47889995575');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11179','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:27','1.11797094345');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11180','consola','toba','/consola/dump',NULL,'2004-07-16 04:36:28','0.464477062225');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11181','consola','toba','/consola/dump',NULL,'2004-07-16 15:27:49','10.9962739944');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11182','consola','toba','/consola/dump',NULL,'2004-07-16 15:27:53','1.51362991333');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11183','consola','toba','/consola/dump',NULL,'2004-07-16 15:27:56','1.17772293091');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11184','consola','toba','/consola/dump',NULL,'2004-07-16 15:27:58','0.509084939957');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11185','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:01','1.20945692062');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11186','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:03','0.507484197617');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11187','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:07','1.4885468483');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11188','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:09','0.509577035904');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11189','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:13','1.88874602318');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11190','consola','toba','/consola/dump',NULL,'2004-07-16 15:28:15','0.476512908936');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11231','consola','toba','/consola/dump',NULL,'2004-07-18 05:37:46','14.5881609917');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11236','consola','toba','/consola/dump',NULL,'2004-07-18 06:25:14','0.670563936234');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11237','consola','toba','/consola/dump',NULL,'2004-07-18 06:25:15','0.144422054291');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11238','consola','toba','/consola/dump',NULL,'2004-07-18 06:25:39','1.32684206963');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11239','consola','toba','/consola/dump',NULL,'2004-07-18 06:25:40','0.338551998138');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11240','consola','toba','/consola/dump',NULL,'2004-07-18 06:45:20','0.830618858337');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11241','consola','toba','/consola/dump',NULL,'2004-07-18 06:45:21','0.139925956726');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11242','consola','toba','/consola/dump',NULL,'2004-07-18 06:47:48','0.716202020645');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11243','consola','toba','/consola/dump',NULL,'2004-07-18 06:47:49','0.140947818756');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11244','consola','toba','/consola/dump',NULL,'2004-07-18 06:49:52','0.715209960938');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11245','consola','toba','/consola/dump',NULL,'2004-07-18 06:49:53','0.138693094254');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11246','consola','toba','/consola/dump',NULL,'2004-07-18 06:50:43','0.543604135513');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11247','consola','toba','/consola/dump',NULL,'2004-07-18 06:50:44','0.137695789337');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11248','consola','toba','/consola/dump',NULL,'2004-07-18 07:11:06','0.633242845535');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11249','consola','toba','/consola/dump',NULL,'2004-07-18 07:11:07','0.140568971634');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11259','consola','toba','/consola/dump',NULL,'2004-07-18 07:19:31','0.675008058548');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11260','consola','toba','/consola/dump',NULL,'2004-07-18 07:19:31','0.141009092331');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11261','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:42','1.328166008');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11262','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:43','0.354668855667');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11263','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:45','0.59415602684');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11264','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:46','0.137762069702');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11265','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:47','0.649455070496');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11266','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:48','0.147083044052');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11267','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:50','0.611185073853');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11268','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:50','0.141203165054');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11269','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:52','0.668032169342');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11270','consola','toba','/consola/dump',NULL,'2004-07-18 07:20:53','0.136260986328');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11271','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:15','2.80809593201');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11272','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:16','0.428106069565');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11273','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:18','0.649260997772');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11274','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:19','0.166496992111');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11275','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:21','0.665282964706');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11276','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:21','0.159483194351');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11277','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:23','0.608090162277');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11278','consola','toba','/consola/dump',NULL,'2004-07-18 17:45:24','0.1554479599');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11279','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:11','1.28907299042');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11280','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:12','0.469973087311');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11281','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:14','0.595973014832');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11282','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:14','0.154912948608');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11283','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:16','0.597385168076');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11284','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:17','0.154722929001');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11285','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:19','0.606716156006');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11286','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:20','0.148754835129');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11287','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:21','0.55309510231');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11288','consola','toba','/consola/dump',NULL,'2004-07-18 17:52:22','0.144850969315');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11289','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:29','1.48632597923');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11290','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:30','0.414745807648');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11291','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:32','0.563673019409');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11292','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:32','0.143405914307');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11293','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:34','0.859266042709');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11294','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:35','0.154376983643');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11295','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:37','0.608690023422');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11296','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:37','0.150034189224');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11297','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:39','0.5454890728');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11298','consola','toba','/consola/dump',NULL,'2004-07-18 17:58:40','0.143743038177');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11316','consola','toba','/consola/info_sql',NULL,'2004-07-18 18:47:34','0.517676115036');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11317','consola','toba','/consola/info_sql',NULL,'2004-07-18 18:50:26','0.387936830521');
INSERT INTO apex_solicitud (solicitud, solicitud_tipo, item_proyecto, item, item_id, momento, tiempo_respuesta) VALUES ('11318','consola','toba','/consola/dump',NULL,'2004-07-18 18:52:00','1.34067702293');

-----------  apex_sesion_browser  ------------------------

INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('271','juan','toba','2004-07-06 09:41:19','2004-07-06 10:11:00',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('272','juan','toba','2004-07-06 10:11:00','2004-07-06 10:11:14',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('273','juan','toba','2004-07-06 10:11:19','2004-07-06 10:13:50',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('274','juan','toba','2004-07-06 10:13:50','2004-07-06 10:20:41',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('275','juan','toba','2004-07-06 10:20:41','2004-07-06 10:42:05',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('277','juan','toba','2004-07-06 10:42:05','2004-07-06 10:56:28',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('278','juan','toba','2004-07-06 10:56:31','2004-07-06 10:59:25',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('276','leo','toba','2004-07-06 10:37:25','2004-07-06 11:00:28',NULL,'d0bdc461fded11eb0d5ee775d9f2e813','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('279','juan','toba','2004-07-06 10:59:25','2004-07-06 11:22:40',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('281','juan','toba','2004-07-06 11:22:40','2004-07-06 11:44:12',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('282','anonimo','toba','2004-07-06 11:44:16','2004-07-06 11:46:56',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('283','juan','toba','2004-07-06 11:46:58','2004-07-06 11:56:49',NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('284','juan','toba','2004-07-06 11:56:50',NULL,NULL,'6ae257b06528a98633405c1de1ef04e1','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('285','juan','toba','2004-07-06 12:59:33',NULL,NULL,'c82db02c53db05a813df0fab15b33c36','168.83.60.144',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('280','leo','toba','2004-07-06 11:00:32','2004-07-06 14:16:42','Se exedio la ventana temporal (40 m.)','d0bdc461fded11eb0d5ee775d9f2e813','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('286','juan','toba','2004-07-06 13:00:24','2004-07-06 15:15:01',NULL,'625a1b8efe02734c207176162181a7de','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('287','leo','toba','2004-07-06 14:31:55','2004-07-06 15:16:11',NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('289','leo','toba','2004-07-06 15:16:11','2004-07-06 15:22:38',NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('290','leo','toba','2004-07-06 15:22:50',NULL,NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('288','juan','toba','2004-07-06 15:15:01','2004-07-06 15:40:17',NULL,'625a1b8efe02734c207176162181a7de','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('291','juan','toba','2004-07-06 15:40:17',NULL,NULL,'625a1b8efe02734c207176162181a7de','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('292','leo','toba','2004-07-06 15:45:23','2004-07-06 16:09:34',NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('293','leo','toba','2004-07-06 16:10:13',NULL,NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('297','juan','toba','2004-07-07 02:35:41','2004-07-07 03:49:01',NULL,'92ec613fe92001ca25a29a27918c4fea','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('298','juan','toba','2004-07-07 03:53:10','2004-07-07 03:58:22',NULL,'fbcb25c888c986ddbddfffb0f710e3d9','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('294','juan','toba','2004-07-07 02:09:46','2004-07-07 10:15:16',NULL,'92ec613fe92001ca25a29a27918c4fea','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('299','leo','toba','2004-07-07 10:15:22','2004-07-07 11:19:23','Se exedio la ventana temporal (40 m.)','a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('300','leo','toba','2004-07-07 11:19:28','2004-07-07 14:35:56','Se exedio la ventana temporal (40 m.)','a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('302','juan','toba','2004-07-07 14:53:58','2004-07-07 15:17:22',NULL,'2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('303','juan','toba','2004-07-07 15:17:22','2004-07-07 15:18:29',NULL,'2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('305','juan','toba','2004-07-07 15:23:48','2004-07-07 15:28:51',NULL,'2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('307','juan','toba','2004-07-07 15:29:09','2004-07-07 15:35:17',NULL,'2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('301','leo','toba','2004-07-07 14:36:07','2004-07-07 16:35:48','Se exedio la ventana temporal (40 m.)','a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('309','juan','toba','2004-07-07 15:35:53','2004-07-07 17:04:02','Se exedio la ventana temporal (40 m.)','2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('311','juan','toba','2004-07-07 17:04:06',NULL,NULL,'2bee2cebbf3ae01ad2344e3d3a4d8941','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('312','juan','toba','2004-07-07 23:02:19','2004-07-07 23:02:40',NULL,'af85a4e64241c2f09237b56ab241546b','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('313','juan','toba','2004-07-07 23:02:42',NULL,NULL,'af85a4e64241c2f09237b56ab241546b','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('314','juan','toba','2004-07-07 23:08:41','2004-07-08 01:08:18','Se exedio la ventana temporal (40 m.)','9a8990583e85d8c90a155c3206bb4b48','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('315','juan','toba','2004-07-08 01:08:25',NULL,NULL,'9a8990583e85d8c90a155c3206bb4b48','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('316','juan','toba','2004-07-08 01:25:41',NULL,NULL,'b0c66991f7290c2693652ac3813ffd60','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('317','juan','toba','2004-07-08 04:07:34','2004-07-08 04:50:02',NULL,'29616ab16789f8fb83e40f82a32f08f2','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('310','leo','toba','2004-07-07 16:35:53','2004-07-08 12:31:28','Se exedio la ventana temporal (40 m.)','a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('319','juan','toba','2004-07-08 14:48:11','2004-07-08 14:52:52',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('318','leo','toba','2004-07-08 12:31:34','2004-07-08 15:01:33','Se exedio la ventana temporal (40 m.)','a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('321','leo','toba','2004-07-08 15:01:37',NULL,NULL,'a62e69b66da2780afc7dd3a97370b274','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('322','juan','toba','2004-07-08 15:06:05','2004-07-08 15:18:49',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('324','dario','toba','2004-07-08 15:22:06','2004-07-08 15:22:17',NULL,'bd4d5e0c3e28e9b15b45545f8cf79109','168.83.60.173',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('326','juan','toba','2004-07-08 15:32:50','2004-07-08 15:41:29',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('327','juan','toba','2004-07-08 15:41:29','2004-07-08 15:51:58',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('329','juan','toba','2004-07-08 16:00:59','2004-07-08 16:01:34',NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('331','juan','toba','2004-07-08 16:59:51',NULL,NULL,'eb2959c20cfeb72cdd32ecf2211d55c8','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('332','juan','toba','2004-07-08 17:11:26','2004-07-08 17:11:46','Cambio de punto de acceso: /usr/local/toba/www/aplicacion.php -> /usr/local/toba/www/admin.php','68be92104924608c2af694890a808f3f','168.83.60.144',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('333','juan','toba','2004-07-08 17:11:49',NULL,NULL,'68be92104924608c2af694890a808f3f','168.83.60.144',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('334','juan','toba','2004-07-08 17:13:24',NULL,NULL,'7b2b39b2bdb363176f99cefe8bbb439f','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('335','juan','toba','2004-07-09 15:26:39','2004-07-09 16:23:29',NULL,'39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('337','juan','toba','2004-07-09 16:24:52','2004-07-09 16:25:28',NULL,'39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('339','juan','toba','2004-07-09 16:26:12','2004-07-09 16:29:31',NULL,'39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('340','juan','toba','2004-07-09 16:28:31','2004-07-09 16:30:25',NULL,'83d2e2d17bec39775a82ffbfb769f773','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('336','juan','toba','2004-07-09 16:23:49','2004-07-12 13:31:03','Se exedio la ventana temporal (40 m.)','39a4e95a7bc1b632b33fbc8775dbd592','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('343','leo','toba','2004-07-12 13:31:10','2004-07-12 15:28:55','Se exedio la ventana temporal (40 m.)','d896d2675f78d9d5e08fff1013027c15','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('344','leo','toba','2004-07-12 15:29:03',NULL,NULL,'d896d2675f78d9d5e08fff1013027c15','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('345','juan','toba','2004-07-13 01:19:34','2004-07-13 01:19:43',NULL,'2488b3fd77e073b60693ecf92500e3b0','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('346','juan','toba','2004-07-13 03:46:23',NULL,NULL,'621acb5a9fe7c6c4873e1de98024163c','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('348','leo','toba','2004-07-13 11:37:20','2004-07-13 12:29:30','Se exedio la ventana temporal (40 m.)','0ec1e03a2617cc43e4a0558f1aad3c01','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('349','leo','toba','2004-07-13 12:29:36','2004-07-13 15:58:52','Se exedio la ventana temporal (40 m.)','0ec1e03a2617cc43e4a0558f1aad3c01','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('350','leo','toba','2004-07-13 15:58:57',NULL,NULL,'0ec1e03a2617cc43e4a0558f1aad3c01','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('351','leo','toba','2004-07-13 17:50:52',NULL,NULL,'296b8d28f89c9c3236924f5e4a934e1d','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('347','leo','toba','2004-07-13 11:17:03','2004-07-14 02:20:28','Cambio de punto de acceso: C:/toba/www/aplicacion.php -> C:/toba/www/admin.php','0ec1e03a2617cc43e4a0558f1aad3c01','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('352','juan','toba','2004-07-14 02:20:28','2004-07-14 06:35:34',NULL,'e1acbea15ac4f00170e6d629a49a1d12','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('353','leo','toba','2004-07-14 11:11:59','2004-07-14 14:44:05','Se exedio la ventana temporal (40 m.)','7d718c9965fcb7a24ba9b20982362da3','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('354','leo','toba','2004-07-14 14:44:11','2004-07-14 16:14:06','Se exedio la ventana temporal (40 m.)','7d718c9965fcb7a24ba9b20982362da3','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('355','leo','toba','2004-07-14 16:14:12',NULL,NULL,'7d718c9965fcb7a24ba9b20982362da3','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('356','juan','toba','2004-07-14 16:19:18',NULL,NULL,'7b244f2ac2db24e720c184d4da7eac6c','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('357','juan','toba','2004-07-14 16:20:53','2004-07-14 17:56:27',NULL,'ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('358','juan','toba','2004-07-14 17:56:27','2004-07-14 17:57:09',NULL,'ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('360','juan','toba','2004-07-14 17:57:30','2004-07-14 19:02:48',NULL,'ecfa933a79098504facc7b6fb830827a','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('365','juan','toba','2004-07-14 19:16:14',NULL,NULL,'4ec1a95ceb181095f1380c7151a3061b','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('366','juan','toba','2004-07-15 01:39:38','2004-07-15 02:19:30',NULL,'87369859ff03165510e2dfed22c16d68','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('368','juan','toba','2004-07-15 02:19:38','2004-07-15 03:41:40','Se exedio la ventana temporal (40 m.)','87369859ff03165510e2dfed22c16d68','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('369','juan','toba','2004-07-15 03:41:43',NULL,NULL,'87369859ff03165510e2dfed22c16d68','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('370','juan','toba','2004-07-15 17:42:19',NULL,NULL,'36f0b760842c1f6d314c53900b318c88','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('371','juan','toba','2004-07-16 03:22:34',NULL,NULL,'e07c40b5a87cf4a23efe22a7771310f4','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('372','juan','toba','2004-07-16 15:31:57',NULL,NULL,'ebdf41c77e0a2fe31bbe82f827bf9d0c','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('374','juan','toba','2004-07-16 15:37:29',NULL,NULL,'f130ce0eb31c990d49b7b4c2c6b10d13','127.0.0.1',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('1','leo','toba','2004-07-06 15:36:23','2004-07-18 06:24:01',NULL,'5d1e5d3792dac76961d583162e3d6d79','168.83.60.212',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('377','juan','toba','2004-07-18 07:18:17','2004-07-18 07:18:31','Cambio de punto de acceso: F:/toba/www/aplicacion.php -> F:/toba/www/admin.php','25d1c4f326e0728e86374964075c38e4','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('378','juan','toba','2004-07-18 07:18:34','2004-07-18 07:20:59',NULL,'25d1c4f326e0728e86374964075c38e4','192.168.0.10',NULL);
INSERT INTO apex_sesion_browser (sesion_browser, usuario, proyecto, ingreso, egreso, observaciones, php_id, ip, punto_acceso) VALUES ('379','juan','toba','2004-07-18 18:10:36','2004-07-18 18:50:36',NULL,'3cba05d6a8fedfa2b668d72d7aa005d3','192.168.0.10',NULL);

-----------  apex_solicitud_browser  ------------------------

INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7261','277','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7342','280','168.83.60.212');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7361','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7364','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7367','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7391','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7418','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7420','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7423','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7425','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7427','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7432','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7463','281','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7481','283','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7486','283','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('7499','283','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8124','286','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8171','286','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8327','294','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8330','294','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8531','297','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8551','297','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8691','300','168.83.60.212');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('8884','316','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('9511','331','127.0.0.1');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('9726','321','168.83.60.212');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('9727','321','168.83.60.212');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10065','344','168.83.60.212');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10426','346','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10442','346','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10445','346','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10550','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10563','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10655','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10657','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10663','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10672','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10674','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10696','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10698','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10701','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10715','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10764','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10790','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10796','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10799','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10801','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10808','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10834','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10843','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10852','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10856','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10858','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10861','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10879','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10886','352','192.168.0.10');
INSERT INTO apex_solicitud_browser (solicitud_browser, sesion_browser, ip) VALUES ('10905','352','192.168.0.10');

-----------  apex_solicitud_wddx  ------------------------

INSERT INTO apex_solicitud_wddx (solicitud_wddx, usuario, ip, instancia, instancia_usuario, paquete) VALUES ('7480','anonimo','168.83.60.144','127.0.0.1','juan','a:3:{s:6:\"texto1\";s:23:\"111 - Texto del mensaje\";s:6:\"texto2\";s:23:\"222 - Texto del mensaje\";s:6:\"texto3\";s:23:\"333 - Texto del mensaje\";}');
INSERT INTO apex_solicitud_wddx (solicitud_wddx, usuario, ip, instancia, instancia_usuario, paquete) VALUES ('7495','anonimo','168.83.60.144','127.0.0.1','juan','a:3:{s:6:\"texto1\";s:23:\"111 - Texto del mensaje\";s:6:\"texto2\";s:23:\"222 - Texto del mensaje\";s:6:\"texto3\";s:23:\"333 - Texto del mensaje\";}');
INSERT INTO apex_solicitud_wddx (solicitud_wddx, usuario, ip, instancia, instancia_usuario, paquete) VALUES ('7497','anonimo','168.83.60.144','127.0.0.1','juan','a:3:{s:6:\"texto1\";s:23:\"111 - Texto del mensaje\";s:6:\"texto2\";s:23:\"222 - Texto del mensaje\";s:6:\"texto3\";s:23:\"333 - Texto del mensaje\";}');

-----------  apex_solicitud_consola  ------------------------

INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7296','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7372','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7374','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7375','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7376','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7377','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('7378','juan',NULL,'f:	oba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8125','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8156','juan',NULL,'',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8202','juan',NULL,'',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8215','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a11_clase_filtro.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8219','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8221','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a11_clase_filtro.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8223','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8228','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a03_solicitudes.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8231','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a11_clase_filtro.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8232','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a10_clase_hoja.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8233','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8234','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8235','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8237','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8239','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8242','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8243','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8245','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8249','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8250','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a13_clase_abms.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8261','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8633','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8634','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8635','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8636','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8638','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8788','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8796','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8797','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8798','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8799','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8808','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8809','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8810','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8811','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8812','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8813','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8814','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('8815','juan',NULL,'i:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('9651','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('9653','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('9655','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('9657','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('9658','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11105','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11132','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql pgsql_a99_perfiles.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11141','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11142','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11143','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11144','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11145','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11146','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a13_clase_abms.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql pgsql_a99_perfiles.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11155','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11156','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11157','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11158','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11159','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11160','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11161','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11162','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11163','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11164','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11165','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11166','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11167','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11168','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11169','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11170','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11171','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11172','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11173','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11174','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11175','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11176','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11177','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11178','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11179','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11180','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11181','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11182','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11183','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11184','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11185','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11186','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11187','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11188','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11189','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11190','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11231','juan',NULL,'e:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11236','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11237','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11238','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11239','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11240','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11241','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11242','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11243','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11244','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11245','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11246','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11247','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11248','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11249','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11259','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11260','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11261','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11262','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11263','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11264','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11265','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11266','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11267','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11268','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11269','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11270','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11271','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11272','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11273','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11274','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11275','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11276','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11277','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11278','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11279','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11280','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11281','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11282','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11283','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11284','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11285','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11286','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11287','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11288','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11289','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11290','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p toba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11291','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11292','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p bahia',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11293','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11294','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p costos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11295','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11296','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p eventos',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11297','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11298','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -h -i -v -p prueba',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11316','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql pgsql_a99_perfiles.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11317','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/info_sql pgsql_a01_nucleo.sql pgsql_a02_dimensiones.sql pgsql_a03_solicitudes.sql pgsql_a04_notas.sql pgsql_a05_mensajes.sql pgsql_a06_mod_datos.sql pgsql_a07_admin_proy.sql pgsql_a10_clase_hoja.sql pgsql_a11_clase_filtro.sql pgsql_a14_clase_lista.sql pgsql_a15_clase_grafico.sql pgsql_a16_clase_cuadro.sql pgsql_a17_clase_cuadro2.sql pgsql_a20_clase_plan.sql pgsql_a50_clase_ut_formulario.sql pgsql_a51_clase_ut_multicheq.sql pgsql_a99_perfiles.sql',NULL);
INSERT INTO apex_solicitud_consola (solicitud_consola, usuario, ip, llamada, entorno) VALUES ('11318','juan',NULL,'f:\\toba/php/nucleo/acceso_consola.php desarrollo juan toba /consola/dump -v -ni -p toba',NULL);

-----------  apex_solicitud_cronometro  ------------------------

INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.433');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','3','nucleo','SOLICITUD: Cargar info ITEM','0.058');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.268');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7296','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.051');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','2','nucleo','basura','0.007');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','4','nucleo','basura','0.026');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.016');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7324','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.656');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.947');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7372','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.457');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.558');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7374','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.35');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.785');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7375','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.349');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.829');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7376','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.359');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.877');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7377','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.364');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.771');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7378','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.05');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','2','nucleo','basura','0.004');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','3','nucleo','SOLICITUD: Cargar info ITEM','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','4','nucleo','basura','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.003');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7470','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.05');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','2','nucleo','basura','0.005');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','4','nucleo','basura','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7480','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.05');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','2','nucleo','SESION: Controlar STATUS SESION','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','3','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','5','nucleo','SOLICITUD: Cargar info ITEM','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','6','nucleo','SOLICITUD BROWSER: Inicializacion (ZONA, VINCULADOR)','0.036');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','7','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','8','nucleo','SOLICITUD: Cargar info OBJETOS','0.016');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','9','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','10','nucleo','SOLICITUD BROWSER: Pagina TIPO (cabecera) ','0.013');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','11','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','12','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','13','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','14','nucleo','SOLICITUD: Crear OBJETO [448]','0.151');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','15','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.022');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','16','nucleo','SOLICITUD BROWSER: Pagina TIPO (pie) ','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7486','17','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.049');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','2','nucleo','basura','0.005');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','4','nucleo','basura','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7495','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.039');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','2','nucleo','basura','0.004');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','3','nucleo','SOLICITUD: Cargar info ITEM','0.296');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','4','nucleo','basura','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('7497','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.409');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.996');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8125','7','nucleo','SOLICITUD: Fin del registro','0.01');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.535');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','3','nucleo','SOLICITUD: Cargar info ITEM','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.781');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8633','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.355');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.79');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8634','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.354');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','3','nucleo','SOLICITUD: Cargar info ITEM','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.834');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8635','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.352');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.879');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8636','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.357');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','3','nucleo','SOLICITUD: Cargar info ITEM','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.777');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8638','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.09');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','3','nucleo','SOLICITUD: Cargar info ITEM','1.147');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','16.561');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8796','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.073');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','3','nucleo','SOLICITUD: Cargar info ITEM','1.282');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.538');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8797','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.103');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','3','nucleo','SOLICITUD: Cargar info ITEM','0.601');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.873');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8798','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.069');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','3','nucleo','SOLICITUD: Cargar info ITEM','1.598');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','20.764');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8808','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.068');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.578');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8809','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.089');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','3','nucleo','SOLICITUD: Cargar info ITEM','1.262');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','45.704');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8811','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','3','nucleo','SOLICITUD: Cargar info ITEM','1.326');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.603');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8812','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','3','nucleo','SOLICITUD: Cargar info ITEM','1.331');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','4.446');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8813','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','3','nucleo','SOLICITUD: Cargar info ITEM','1.258');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','6.829');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8814','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.064');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','3','nucleo','SOLICITUD: Cargar info ITEM','1.149');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.892');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8815','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.034');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','2','nucleo','SESION: Controlar STATUS SESION','0.036');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','3','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','5','nucleo','SOLICITUD: Cargar info ITEM','1.171');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','6','nucleo','SOLICITUD BROWSER: Inicializacion (ZONA, VINCULADOR)','0.696');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','7','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','8','nucleo','SOLICITUD: Cargar info OBJETOS','0.013');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','9','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','10','nucleo','SOLICITUD BROWSER: Pagina TIPO (cabecera) ','0.017');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','11','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','12','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','13','nucleo','basura','0.033');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','14','nucleo','SOLICITUD: Crear OBJETO [431]','0.157');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','15','nucleo','basura','0.021');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','16','nucleo','SOLICITUD: Crear OBJETO [412]','0.065');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','17','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','18','nucleo','SOLICITUD: Crear OBJETO [411]','0.586');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','19','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.4');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','20','nucleo','SOLICITUD BROWSER: Pagina TIPO (pie) ','0.01');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('8884','21','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.051');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','2','nucleo','SESION: Controlar STATUS SESION','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','3','nucleo','basura','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','5','nucleo','SOLICITUD: Cargar info ITEM','0.066');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','6','nucleo','SOLICITUD BROWSER: Inicializacion (ZONA, VINCULADOR)','0.037');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','7','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','8','nucleo','SOLICITUD: Cargar info OBJETOS','0.015');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','9','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','10','nucleo','SOLICITUD BROWSER: Pagina TIPO (cabecera) ','0.097');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','11','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','12','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','13','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','14','nucleo','SOLICITUD BROWSER: Pagina TIPO (pie) ','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9511','15','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.575');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','3','nucleo','SOLICITUD: Cargar info ITEM','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','3.156');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9651','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.35');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','3','nucleo','SOLICITUD: Cargar info ITEM','0.059');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.027');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9653','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.358');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.178');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9655','7','nucleo','SOLICITUD: Fin del registro','0.003');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.362');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','3','nucleo','SOLICITUD: Cargar info ITEM','0.061');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.925');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9657','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.353');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','3','nucleo','SOLICITUD: Cargar info ITEM','0.06');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.791');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('9658','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.151');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','3','nucleo','SOLICITUD: Cargar info ITEM','0.108');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','6.256');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11141','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.158');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','3','nucleo','SOLICITUD: Cargar info ITEM','0.264');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.898');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11142','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.161');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','3','nucleo','SOLICITUD: Cargar info ITEM','0.181');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.95');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11143','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','3','nucleo','SOLICITUD: Cargar info ITEM','0.183');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.96');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11144','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','3','nucleo','SOLICITUD: Cargar info ITEM','0.188');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.846');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11145','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.15');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','3','nucleo','SOLICITUD: Cargar info ITEM','0.119');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','4.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11155','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.199');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','3','nucleo','SOLICITUD: Cargar info ITEM','0.17');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.636');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11156','7','nucleo','SOLICITUD: Fin del registro','0.018');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.19');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.693');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11157','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.186');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','3','nucleo','SOLICITUD: Cargar info ITEM','0.164');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.659');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11158','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.189');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.595');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11159','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.18');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.843');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11160','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.139');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','3','nucleo','SOLICITUD: Cargar info ITEM','0.152');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.253');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11161','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.182');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','3','nucleo','SOLICITUD: Cargar info ITEM','0.164');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.917');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11162','7','nucleo','SOLICITUD: Fin del registro','0.003');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.143');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','3','nucleo','SOLICITUD: Cargar info ITEM','0.209');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.848');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11163','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.181');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.904');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11164','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','3','nucleo','SOLICITUD: Cargar info ITEM','0.214');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.935');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11165','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.187');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','3','nucleo','SOLICITUD: Cargar info ITEM','0.169');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.951');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11166','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','3','nucleo','SOLICITUD: Cargar info ITEM','0.19');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.978');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11167','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.189');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.964');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11168','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.164');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','3','nucleo','SOLICITUD: Cargar info ITEM','0.193');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.794');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11169','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.188');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','3','nucleo','SOLICITUD: Cargar info ITEM','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.856');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11170','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.147');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','3','nucleo','SOLICITUD: Cargar info ITEM','0.145');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.305');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11171','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.183');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','3','nucleo','SOLICITUD: Cargar info ITEM','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.503');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11172','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.167');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','3','nucleo','SOLICITUD: Cargar info ITEM','0.182');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.824');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11173','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.184');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','3','nucleo','SOLICITUD: Cargar info ITEM','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.12');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11174','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','3','nucleo','SOLICITUD: Cargar info ITEM','0.19');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.845');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11175','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.186');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','3','nucleo','SOLICITUD: Cargar info ITEM','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.138');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11176','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','3','nucleo','SOLICITUD: Cargar info ITEM','0.184');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.877');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11177','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.187');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','3','nucleo','SOLICITUD: Cargar info ITEM','0.169');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.123');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11178','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','3','nucleo','SOLICITUD: Cargar info ITEM','0.186');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.768');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11179','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.183');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','3','nucleo','SOLICITUD: Cargar info ITEM','0.165');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.116');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11180','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.158');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','3','nucleo','SOLICITUD: Cargar info ITEM','1.374');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','9.462');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11181','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.183');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','3','nucleo','SOLICITUD: Cargar info ITEM','0.164');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.165');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11182','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','3','nucleo','SOLICITUD: Cargar info ITEM','0.185');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.83');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11183','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.21');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','3','nucleo','SOLICITUD: Cargar info ITEM','0.169');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.129');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11184','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','3','nucleo','SOLICITUD: Cargar info ITEM','0.184');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.861');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11185','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.191');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','3','nucleo','SOLICITUD: Cargar info ITEM','0.163');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.153');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11186','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.162');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','3','nucleo','SOLICITUD: Cargar info ITEM','0.185');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.138');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11187','7','nucleo','SOLICITUD: Fin del registro','0.003');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.196');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','3','nucleo','SOLICITUD: Cargar info ITEM','0.168');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.145');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11188','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.238');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','3','nucleo','SOLICITUD: Cargar info ITEM','0.259');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.39');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11189','7','nucleo','SOLICITUD: Fin del registro','0.002');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.192');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','3','nucleo','SOLICITUD: Cargar info ITEM','0.165');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.118');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11190','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','2.362');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','3','nucleo','SOLICITUD: Cargar info ITEM','2.73');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','9.494');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11231','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.049');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.591');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11236','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.05');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.064');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11237','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.101');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.196');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11238','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.263');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11239','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.232');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','3','nucleo','SOLICITUD: Cargar info ITEM','0.031');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.566');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11240','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.064');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11241','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.22');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','3','nucleo','SOLICITUD: Cargar info ITEM','0.031');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.464');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11242','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.066');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11243','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.221');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.464');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11244','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.064');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11245','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.466');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11246','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.064');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11247','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.107');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','3','nucleo','SOLICITUD: Cargar info ITEM','0.031');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.494');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11248','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.066');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11249','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.05');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.594');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11259','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.066');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11260','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.252');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11261','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.28');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11262','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.099');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.465');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11263','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.063');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11264','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.098');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.521');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11265','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.044');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.074');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11266','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.535');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11267','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.045');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.066');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11268','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.159');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.48');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11269','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.044');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.063');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11270','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.062');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','3','nucleo','SOLICITUD: Cargar info ITEM','0.407');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','2.338');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11271','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.353');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11272','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.572');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11273','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.09');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11274','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.587');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11275','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.082');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11276','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.051');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.527');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11277','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.08');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11278','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','3','nucleo','SOLICITUD: Cargar info ITEM','0.032');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.208');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11279','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.134');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','3','nucleo','SOLICITUD: Cargar info ITEM','0.028');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.307');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11280','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.518');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11281','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.077');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11282','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.053');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.513');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11283','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.077');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11284','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.049');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.527');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11285','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.071');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11286','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.049');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.474');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11287','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.067');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11288','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.189');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','3','nucleo','SOLICITUD: Cargar info ITEM','0.032');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.264');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11289','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.336');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11290','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.487');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11291','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','3','nucleo','SOLICITUD: Cargar info ITEM','0.028');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.067');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11292','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.307');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','3','nucleo','SOLICITUD: Cargar info ITEM','0.038');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.513');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11293','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.047');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.077');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11294','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.53');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11295','7','nucleo','SOLICITUD: Fin del registro','0.001');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.072');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11296','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.048');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','3','nucleo','SOLICITUD: Cargar info ITEM','0.03');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.467');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11297','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.046');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','0.068');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11298','7','nucleo','SOLICITUD: Fin del registro','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','1','nucleo','INICIO: Abrir la conexion a la INSTANCIA','0.111');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','2','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','3','nucleo','SOLICITUD: Cargar info ITEM','0.029');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','4','nucleo','basura','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','5','nucleo','SOLICITUD: --> INICIO ACTIVIDAD!','0');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','6','nucleo','SOLICITUD: --> FIN ACTIVIDAD!','1.2');
INSERT INTO apex_solicitud_cronometro (solicitud, marca, nivel_ejecucion, texto, tiempo) VALUES ('11318','7','nucleo','SOLICITUD: Fin del registro','0.001');

-----------  apex_solicitud_obj_observacion  ------------------------

INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('70','error','7261','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('71','error','7342','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('72','error','7361','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('73','error','7364','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('74','error','7367','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('75','error','7391','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('76','error','7418','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (cronometro >= \'1\')  AND  (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Attribute \"cronometro\" not found
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('77','error','7420','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (llamada ~* \'prueba\')  AND  (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('78','error','7423','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('79','error','7425','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('80','error','7427','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('81','error','7432','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (tiempo_respuesta >= ) ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Unable to identify a postfix operator \'>=\' for type \'double precision\'
	You may need to add parentheses or an explicit cast
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('82','error','7463','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (cronometro >= \'1\') ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Attribute \"cronometro\" not found
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('83','error','7481','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('84','error','7499','toba','447','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT
p.descripcion as proyecto,
se.sesion_browser as sesion,
se.usuario as usuario,
se.ingreso as sesion_ingreso,
se.egreso as sesion_egreso,
se.ip as ip,

(SELECT count(*) FROM apex_solicitud_browser sb WHERE sb.sesion_browser = se.sesion_browser  AND  (s.item_proyecto = \'toba\') ) as solicitudes

FROM apex_proyecto p, 
apex_sesion_browser se 
WHERE p.proyecto = se.proyecto
 AND  (s.item_proyecto = \'toba\') 
ORDER BY 1,2 DESC; - [ERROR] ERROR:  Relation \"s\" does not exist
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('85','error','8124','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (cronometro >= \'1\') ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Attribute \"cronometro\" not found
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('86','error','8171','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( (cronometro >= \'1\') ) 
ORDER BY 3 DESC - [ERROR] ERROR:  Attribute \"cronometro\" not found
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('87','error','8327','toba','458','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT log_error_login,
momento,
usuario,
clave,
ip,
gravedad,
mensaje,
punto_acceso,
\\\' \\\'
FROM apex_log_error_login
 - [ERROR] ERROR:  syntax error at or near \"\\\" at character 95
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('88','error','8330','toba','458','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT log_error_login,
momento,
usuario,
clave,
ip,
gravedad,
mensaje,
punto_acceso,
FROM apex_log_error_login
 - [ERROR] ERROR:  syntax error at or near \"FROM\" at character 95
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('93','error','8531','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( ( (=1)
							AND  (=2002) )) 
ORDER BY 3 DESC - [ERROR] ERROR:  syntax error at or near \"=\" at character 406
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('94','error','8551','toba','454','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo_respuesta,
sc.usuario as usuario,
sc.ip as ip,
sc.llamada as llamada,
sc.entorno as entorno,
(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud) as cronometro
FROM apex_solicitud s, apex_solicitud_consola sc
WHERE s.solicitud = sc.solicitud_consola  AND  ( ( (date_part(\\\'month\\\'=1)
							AND  (s.momento)=2002) )) 
ORDER BY 3 DESC - [ERROR] ERROR:  syntax error at or near \"\\\" at character 416
');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('95','error','8691','toba','460','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT usuario,clave,nombre FROM apex_usuarios - [ERROR] ERROR:  Relation \"apex_usuarios\" does not exist');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('96','error','9726','toba','448','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo,
sw.usuario as usuario,
sw.ip as ip,
sw.instancia as instancia,
sw.instancia_usuario as instancia_usuario,
sw.paquete as paquete,

(SELECT COUNT(*) FROM apex_solicitud_observacion sso WHERE sso.solicitud = s.solicitud  AND  (solicitud =  AND solicitud = \'7495\') ) as observacion,

(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud   AND  (solicitud =  AND solicitud = \'7495\') ) as cronometro,

(SELECT COUNT(*) FROM apex_solicitud_obj_observacion soo WHERE soo.solicitud = s.solicitud   AND  (solicitud =  AND solicitud = \'7495\') ) as observacion_obj

FROM apex_solicitud_wddx as sw, apex_solicitud s 
WHERE s.solicitud = sw.solicitud_wddx
 AND  (solicitud =  AND solicitud = \'7495\')  - [ERROR] ERROR:  parser: parse error at or near \"AND\" at character 349');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('97','error','9727','toba','448','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT s.solicitud as solicitud,
s.item as item,
s.momento as momento,
s.tiempo_respuesta as tiempo,
sw.usuario as usuario,
sw.ip as ip,
sw.instancia as instancia,
sw.instancia_usuario as instancia_usuario,
sw.paquete as paquete,

(SELECT COUNT(*) FROM apex_solicitud_observacion sso WHERE sso.solicitud = s.solicitud  AND  (solicitud =  AND solicitud = \'7497\') ) as observacion,

(SELECT COUNT(*) FROM apex_solicitud_cronometro soc WHERE soc.solicitud = s.solicitud   AND  (solicitud =  AND solicitud = \'7497\') ) as cronometro,

(SELECT COUNT(*) FROM apex_solicitud_obj_observacion soo WHERE soo.solicitud = s.solicitud   AND  (solicitud =  AND solicitud = \'7497\') ) as observacion_obj

FROM apex_solicitud_wddx as sw, apex_solicitud s 
WHERE s.solicitud = sw.solicitud_wddx
 AND  (solicitud =  AND solicitud = \'7497\')  - [ERROR] ERROR:  parser: parse error at or near \"AND\" at character 349');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('98','error','10065','toba','467','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT version
descripcion
fecha
observaciones
proyecto
actual
FROM apex_ap_version; - [ERROR] ERROR:  parser: parse error at or near \"descripcion\" at character 17');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('99','error','10426','toba','211','OBJETO LISTA [generar_html] - No se genero un recordset [SQL] SELECT d.dimension,
p.usuario_perfil_datos,
d.nombre, 
d.dimension_tipo, 
t.descripcion,
d.fuente_datos
FROM apl_dimension d,
apl_dimension_perfil_datos p,
apl_dimension_tipo t

WHERE d.dimension = p.dimension
AND t.dimension_tipo = d.dimension_tipo

ORDER BY 2; - [ERROR] ERROR:  relation \"apl_dimension\" does not exist');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('100','error','10442','toba','211','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] sql: SELECT d.proyecto as dim_proy
d.dimension as dim,
p.usuario_perfil_datos_proyecto as usu_proy,
p.usuario_perfil_datos as usu,
d.nombre as nombre, 
d.dimension_tipo as tipo, 
t.nombre as tipo_nombre,
d.fuente_datos as fuente,
t.item_editor_restric as item_editor,
t.ventana_editor_x as x,
t.ventana_editor_y as y
FROM apex_dimension d,
apex_dimension_perfil_datos p,
apex_dimension_tipo t
WHERE d.dimension = p.dimension
AND d.proyecto = p.dimension_proyecto
AND t.dimension_tipo = d.dimension_tipo
AND t.proyecto = d.dimension_tipo_proyecto
 ORDER BY 2; - [ERROR] ERROR:  syntax error at or near \"sql\" at character 1');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('101','error','10445','toba','211','OBJETO CUADRO [cargar_datos] - No se genero un recordset [SQL] SELECT d.proyecto as dim_proy
d.dimension as dim,
p.usuario_perfil_datos_proyecto as usu_proy,
p.usuario_perfil_datos as usu,
d.nombre as nombre, 
d.dimension_tipo as tipo, 
t.nombre as tipo_nombre,
d.fuente_datos as fuente,
t.item_editor_restric as item_editor,
t.ventana_editor_x as x,
t.ventana_editor_y as y
FROM apex_dimension d,
apex_dimension_perfil_datos p,
apex_dimension_tipo t
WHERE d.dimension = p.dimension
AND d.proyecto = p.dimension_proyecto
AND t.dimension_tipo = d.dimension_tipo
AND t.proyecto = d.dimension_tipo_proyecto
 ORDER BY 2; - [ERROR] ERROR:  syntax error at or near \"d\" at character 32');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('102','error','10550','toba','210','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('103','error','10563','toba','210','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('104','error','10655','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('105','error','10657','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('106','error','10663','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('107','error','10672','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('108','error','10674','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('109','error','10696','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('110','error','10698','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('111','error','10701','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('112','error','10715','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('113','error','10764','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('114','error','10790','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('115','error','10796','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('116','error','10799','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('117','error','10801','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('118','error','10808','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('119','error','10834','toba','135','[recuperar_registro_db] - No se genero un recordset [SQL]  SELECT proyecto, objeto, clase_proyecto, clase, subclase, subclase_archivo, fuente_datos_proyecto, fuente_datos, nombre, descripcion FROM apex_objeto WHERE ( proyecto = \'\') AND ( objeto = \'\'); - [ERROR] ERROR:  invalid input syntax for integer: \"\"');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('120','error','10843','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('121','error','10852','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('122','error','10856','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('123','error','10858','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('124','error','10861','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('125','error','10879','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('126','error','10886','toba','214','[formatear_clave] - La clave especificada esta mal formada');
INSERT INTO apex_solicitud_obj_observacion (solicitud_obj_observacion, solicitud_obj_obs_tipo, solicitud, objeto_proyecto, objeto, observacion) VALUES ('127','error','10905','toba','214','[formatear_clave] - La clave especificada esta mal formada');

-----------  apex_log_sistema  ------------------------

INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('14','2004-07-06 15:36:56','leo','bug','OBJETO UT FORMULARIO: El objeto solicitado NO EXISTE. id[toba,139] clase[objeto_mt_abms]');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('99','2004-07-06 11:03:19','anonimo','bug','SOLICITUD: No se pudo registrar la observacion: ERROR:  apex_sol_obs_fk_sol_ot referential integrity violation - key referenced from apex_solicitud_observacion not found in apex_solicitud_obs_tipo
-INSERT INTO apex_solicitud_observacion (solicitud,solicitud_obs_tipo_proyecto,solicitud_obs_tipo,observacion) 
								VALUES (\'7324\',\'\',\'usr_anonimo\',\'desarrollo...\');');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('100','2004-07-06 11:43:31','anonimo','bug','SOLICITUD: No se pudo registrar la observacion: ERROR:  apex_sol_obs_fk_sol_ot referential integrity violation - key referenced from apex_solicitud_observacion not found in apex_solicitud_obs_tipo
-INSERT INTO apex_solicitud_observacion (solicitud,solicitud_obs_tipo_proyecto,solicitud_obs_tipo,observacion) 
								VALUES (\'7470\',\'\',\'usr_anonimo\',\'desarrollo...\');');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('101','2004-07-06 11:44:16','anonimo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/acceso\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('102','2004-07-06 11:44:16','anonimo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('103','2004-07-06 12:00:16','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/actividad/sesiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('104','2004-07-06 12:00:16','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('105','2004-07-06 12:00:19','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/actividad/sesiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('106','2004-07-06 12:00:19','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('107','2004-07-06 12:00:41','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/actividad/sesiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('108','2004-07-06 12:00:41','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('109','2004-07-06 12:06:25','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							io.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias do,
							apex_objeto o,
							apex_clase c
					WHERE	do.objeto_proveedor = o.objeto
					AND		do.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		do.objeto_consumidor_proyecto=\'toba\'
					AND		do.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  parser: parse error at or near \"do\" at character 510
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('110','2004-07-06 12:07:09','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							do.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias do,
							apex_objeto o,
							apex_clase c
					WHERE	do.objeto_proveedor = o.objeto
					AND		do.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		do.objeto_consumidor_proyecto=\'toba\'
					AND		do.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  parser: parse error at or near \"do\" at character 198
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('111','2004-07-06 12:07:19','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							do.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias do,
							apex_objeto o,
							apex_clase c
					WHERE	do.objeto_proveedor = o.objeto
					AND		do.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		do.objeto_consumidor_proyecto=\'toba\'
					AND		do.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  parser: parse error at or near \"do\" at character 198
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('112','2004-07-06 12:08:19','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.orden
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('113','2004-07-06 12:08:21','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.orden
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('114','2004-07-06 12:08:23','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.orden
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('115','2004-07-06 12:08:26','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.orden as		 			objeto_orden,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.orden
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('116','2004-07-06 12:09:03','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.objeto_proveedor_proyecto
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('117','2004-07-06 12:09:05','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.objeto_proveedor_proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.objeto_consumidor_proyecto=\'toba\'
					AND		d.objeto_consumidor=\'438\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute d.objeto_proveedor_proyecto
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('118','2004-07-06 13:11:44','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"solicitud_tipo\": can\'t parse \"solicitud_tipo\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('119','2004-07-06 13:11:49','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'proyecto\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"proyecto\": can\'t parse \"proyecto\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('120','2004-07-06 13:11:51','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'buscar_ereg\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"buscar_ereg\": can\'t parse \"buscar_ereg\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('121','2004-07-06 13:11:53','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'Cronometro\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"Cronometro\": can\'t parse \"Cronometro\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('122','2004-07-06 13:11:56','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"solicitud_tipo\": can\'t parse \"solicitud_tipo\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('123','2004-07-06 13:12:57','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"solicitud_tipo\": can\'t parse \"solicitud_tipo\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('124','2004-07-06 13:19:54','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							d.identificador as 			objeto_identificador,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_objeto_dependencias d,
							apex_objeto o,
							apex_clase c
					WHERE	d.objeto_proveedor = o.objeto
					AND		d.proyecto = o.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.objeto_consumidor=\'buscar_ereg\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  pg_atoi: error in \"buscar_ereg\": can\'t parse \"buscar_ereg\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('125','2004-07-06 13:27:18','juan','bug','BARRA INFERIOR editor item: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	o.proyecto as				objeto_proyecto,
							o.objeto as					objeto,
							o.nombre as					objeto_nombre,
							o.clase_proyecto as			clase_proyecto,
							o.clase as					clase,
							c.icono as					clase_icono,
							c.editor_proyecto as		clase_editor_proyecto,
							c.editor_item as			clase_editor,
							c.instanciador_proyecto as	clase_instanciador_proyecto,
							c.instanciador_item as		clase_instanciador
					FROM	apex_dimension d,
							apex_objeto_filtro f,
							apex_objeto o,
							apex_clase c
					WHERE	f.objeto = o.objeto
					AND		f.proyecto = o.proyecto
					AND		f.dimension = d.dimension
					AND		f.dimension_proyecto = d.proyecto
					AND		o.clase_proyecto = c.proyecto
					AND		o.clase = c.clase
					AND		d.proyecto=\'toba\'
					AND		d.dimension=\'proyecto\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  No such attribute f.objeto
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('126','2004-07-06 14:59:50','juan','bug','SOLICITUD CONSOLA: No se pudo registrar la solicitud: ERROR:  value too long for type character varying(255)
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('127','2004-07-06 15:03:07','juan','bug','SOLICITUD CONSOLA: No se pudo registrar la solicitud: ERROR:  value too long for type character varying(255)
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('128','2004-07-06 15:06:31','juan','bug','SOLICITUD CONSOLA: No se pudo registrar la solicitud: ERROR:  value too long for type character varying(255)
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('129','2004-07-06 15:41:40','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/actividad/log_error_login\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('130','2004-07-06 15:41:40','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('131','2004-07-06 16:07:14','leo','bug','OBJETO CUADRO - COLUMNA: No hay informacion sobre elementos de formulario en: id[toba,459] clase[objeto_cuadro]');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('132','2004-07-06 16:57:14','leo','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"\\\" at character 8 -- SQL: SELECT \\\'1\\\' FROM apex_log_ip_rechazada -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('133','2004-07-06 17:06:05','leo','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"\\\" at character 8 -- SQL: SELECT \\\'1\\\' FROM apex_log_ip_rechazada -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('134','2004-07-06 17:06:20','leo','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"\\\" at character 8 -- SQL: SELECT \\\'1\\\' FROM apex_log_ip_rechazada -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('135','2004-07-06 17:13:03','leo','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"\\\" at character 8 -- SQL: SELECT \\\'1\\\' FROM apex_log_ip_rechazada -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('136','2004-07-06 17:16:34','juan','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'fantasma\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('137','2004-07-07 02:58:18','juan','bug','COMBO DB: No se genero el recordset. ERROR:  syntax error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\'fantasma\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('138','2004-07-07 02:58:24','juan','bug','COMBO DB: No se genero el recordset. ERROR:  syntax error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\'fantasma\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('139','2004-07-07 02:58:35','juan','bug','COMBO DB: No se genero el recordset. ERROR:  syntax error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\'fantasma\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('140','2004-07-07 02:58:39','juan','bug','COMBO DB: No se genero el recordset. ERROR:  syntax error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\'fantasma\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('141','2004-07-07 02:58:43','juan','bug','COMBO DB: No se genero el recordset. ERROR:  syntax error at or near \"\\\" at character 94
 -- SQL: SELECT solicitud_tipo, descripcion_corta
FROM apex_solicitud_tipo 
WHERE solicitud_tipo <> \\\'fantasma\\\' -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('142','2004-07-07 12:18:42','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/objetos/instanciadores/cuadro_reg\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('143','2004-07-07 12:18:42','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('144','2004-07-07 16:55:11','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/objetos/editores/cuadro_reg\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('145','2004-07-07 16:55:11','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('146','2004-07-07 16:56:14','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/objetos/editores/cuadro_reg\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('147','2004-07-07 16:56:14','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('148','2004-07-08 02:57:52','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('149','2004-07-08 02:57:52','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('150','2004-07-08 02:57:56','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('151','2004-07-08 02:57:56','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('152','2004-07-08 02:58:43','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('153','2004-07-08 02:58:43','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('154','2004-07-08 02:58:53','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('155','2004-07-08 02:58:53','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('156','2004-07-08 02:58:57','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('157','2004-07-08 02:58:57','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('158','2004-07-08 02:59:30','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('159','2004-07-08 02:59:30','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('160','2004-07-08 02:59:40','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('161','2004-07-08 02:59:40','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('162','2004-07-08 02:59:48','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('163','2004-07-08 02:59:48','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('164','2004-07-08 03:00:06','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/proyectos/versiones\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('165','2004-07-08 03:00:06','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('166','2004-07-08 15:46:57','juan','bug','COMBO DB: No se genero el recordset. ERROR:  No such attribute d.dimension_proyecto
 -- SQL: SELECT d.dimension_proyecto, d.dimension, \'[\' 
|| d.proyecto || \'] - \' || d.nombre FROM 
apex_dimension d, apex_dimension_tipo t WHERE 
d.dimension_tipo = t.dimension_tipo AND 
t.dimension_tipo_perfil <> \'no\' ORDER BY 2 -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('167','2004-07-08 15:48:14','juan','bug','COMBO DB: No se genero el recordset. ERROR:  parser: parse error at or near \"AND\" at character 100
 -- SQL: SELECT d.proyecto, d.dimension, d.nombre 
FROM 
apex_dimension d, 
apex_dimension_tipo t WHERE  AND  ((proyecto = \'toba\' )) 
d.dimension_tipo = t.dimension_tipo AND 
t.dimension_tipo_perfil <> \'no\' ORDER BY 2 -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('168','2004-07-08 15:48:35','juan','bug','COMBO DB: No se genero el recordset. ERROR:  Column reference \"proyecto\" is ambiguous
 -- SQL: SELECT d.proyecto, d.dimension, d.nombre 
FROM 
apex_dimension d, 
apex_dimension_tipo t WHERE 
d.dimension_tipo = t.dimension_tipo AND 
t.dimension_tipo_perfil <> \'no\' 
 AND  ((proyecto = \'toba\' )) 
ORDER BY 2 -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('169','2004-07-08 15:50:33','juan','bug','COMBO DB: No se genero el recordset. ERROR:  Column reference \"proyecto\" is ambiguous
 -- SQL: SELECT d.proyecto, d.dimension, d.nombre 
FROM 
apex_dimension d, 
apex_dimension_tipo t 
WHERE d.dimension_tipo = t.dimension_tipo 
AND d.dimension_tipo_proyecto = t.proyecto
AND t.dimension_tipo_perfil <> \'no\' 
 AND  ((proyecto = \'toba\' )) 
ORDER BY 2 -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('170','2004-07-08 15:52:03','juan','bug','OBJETO HOJA: NO se pudo cargar las DIRECTIVAS.  id[costos,461]  -- SQL: 	SELECT	d.objeto_hoja_directiva_tipo as 		tipo,
							d.nombre as 							nombre,
							cf.funcion as 							formato,
							ce.css as 								estilo,
							dim.dimension as						dimension,
							d.par_tabla as							dimension_tabla,
							d.par_columna as						dimension_columna,
							u.usuario_perfil_datos as				dimension_control_perfil
					FROM	apex_objeto_hoja_directiva d 
							LEFT OUTER JOIN apex_columna_formato cf USING(columna_formato)
							LEFT OUTER JOIN apex_columna_estilo ce USING(columna_estilo)
							LEFT OUTER JOIN apex_dimension dim ON (d.par_dimension = dim.dimension)
							LEFT OUTER JOIN apex_dimension_perfil_datos u ON (d.par_dimension = u.dimension) AND (u.usuario_perfil_datos = \'no\')
					WHERE	d.objeto_hoja_proyecto=\'costos\'
    	            AND     d.objeto_hoja=\'461\'
					ORDER BY	d.columna; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('171','2004-07-08 15:55:46','juan','bug','OBJETO HOJA: NO se pudo cargar las DIRECTIVAS.  id[costos,461]  -- SQL: 	SELECT	d.objeto_hoja_directiva_tipo as 		tipo,
							d.nombre as 							nombre,
							cf.funcion as 							formato,
							ce.css as 								estilo,
							dim.dimension as						dimension,
							d.par_tabla as							dimension_tabla,
							d.par_columna as						dimension_columna,
							u.usuario_perfil_datos as				dimension_control_perfil
					FROM	apex_objeto_hoja_directiva d 
							LEFT OUTER JOIN apex_columna_formato cf USING(columna_formato)
							LEFT OUTER JOIN apex_columna_estilo ce USING(columna_estilo)
							LEFT OUTER JOIN apex_dimension dim ON (d.par_dimension = dim.dimension)
							LEFT OUTER JOIN apex_dimension_perfil_datos u ON (d.par_dimension = u.dimension) AND (u.usuario_perfil_datos = \'no\')
					WHERE	d.objeto_hoja_proyecto=\'costos\'
    	            AND     d.objeto_hoja=\'461\'
					ORDER BY	d.columna; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('172','2004-07-08 16:14:56','juan','bug','OBJETO HOJA: NO se pudo cargar las DIRECTIVAS.  id[costos,461]  -- SQL: 	SELECT	d.objeto_hoja_directiva_tipo as 		tipo,
							d.nombre as 							nombre,
							cf.funcion as 							formato,
							ce.css as 								estilo,
							dim.dimension as						dimension,
							d.par_tabla as							dimension_tabla,
							d.par_columna as						dimension_columna,
							u.usuario_perfil_datos as				dimension_control_perfil
					FROM	apex_objeto_hoja_directiva d 
							LEFT OUTER JOIN apex_columna_formato cf USING(columna_formato)
							LEFT OUTER JOIN apex_columna_estilo ce USING(columna_estilo)
							LEFT OUTER JOIN apex_dimension dim ON (d.par_dimension = dim.dimension)
							LEFT OUTER JOIN apex_dimension_perfil_datos u ON (d.par_dimension = u.dimension) AND (u.usuario_perfil_datos = \'no\')
					WHERE	d.objeto_hoja_proyecto=\'costos\'
    	            AND     d.objeto_hoja=\'461\'
					ORDER BY	d.columna; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('173','2004-07-08 16:18:43','juan','seguridad','El USUARIO solicito acceder al ITEM \'costos,/estadisticas/proyectos\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('174','2004-07-08 16:18:43','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('175','2004-07-12 16:41:11','leo','seguridad','El USUARIO solicito acceder al ITEM \'toba,/actividad/rechazar_ip\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('176','2004-07-12 16:41:11','leo','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('177','2004-07-12 17:41:54',NULL,'falta','SOLICITUD BROWSER: El ITEM de item no es de tipo: BROWSER.');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('178','2004-07-12 17:42:00',NULL,'falta','SOLICITUD BROWSER: El ITEM de item no es de tipo: BROWSER.');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('179','2004-07-12 17:42:20',NULL,'falta','SOLICITUD BROWSER: El ITEM de item no es de tipo: BROWSER.');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('180','2004-07-13 04:29:37','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/usuarios/grupo\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('181','2004-07-13 04:29:37','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('182','2004-07-13 04:29:38','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/usuarios/grupo\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('183','2004-07-13 04:29:38','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('184','2004-07-13 04:29:44','juan','seguridad','El USUARIO solicito acceder al ITEM \'toba,/admin/usuarios/grupo\'. (El usuario no posee PERMISOS)');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('185','2004-07-13 04:29:44','juan','falta','SOLICITUD: El usuario no posee permisos para acceder al item solicitado. Se ha generado un informe!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('186','2004-07-13 05:26:55','juan','bug','OBJETO CUADRO - COLUMNA: No hay informacion sobre elementos de formulario en: id[toba,211] clase[objeto_cuadro]');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('187','2004-07-14 05:59:31','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  ORDER BY position 5 is not in select list');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('188','2004-07-14 06:00:46','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  ORDER BY position 5 is not in select list');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('189','2004-07-14 06:02:08','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion: [\'elemento\']. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('190','2004-07-14 06:03:25','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('191','2004-07-14 06:03:26','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('192','2004-07-14 06:03:29','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Cronometro\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('193','2004-07-14 06:03:31','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'lapso\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('194','2004-07-14 06:03:33','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Cronometro\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('195','2004-07-14 06:03:35','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('196','2004-07-14 06:04:01','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('197','2004-07-14 06:04:03','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('198','2004-07-14 06:04:06','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'lapso\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('199','2004-07-14 06:04:08','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfl_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'buscar_ereg\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('200','2004-07-14 06:04:57','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfil_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'buscar_ereg\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('201','2004-07-14 06:05:35','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfil_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('202','2004-07-14 06:05:37','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usario_perfil_datos = d.usuario_perfil_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'Mes\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  column p.usario_perfil_datos does not exist');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('203','2004-07-14 06:08:41','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usuario_perfil_datos = d.usuario_perfil_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  ORDER BY position 5 is not in select list');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('204','2004-07-14 06:08:42','juan','bug','BARRA INFERIOR editor DIMENSIONES: NO se pudo cargar definicion. - [SQL]  	SELECT	p.proyecto as 					proyecto,
							p.usuario_perfil_datos as 		perfil_datos,
							p.nombre as 					nombre,
							p.descripcion as 				descripcion
					FROM	apex_usuario_perfil_datos p,
							apex_dimension_perfil_datos d
					WHERE	p.usuario_perfil_datos = d.usuario_perfil_datos
					AND		p.proyecto = d.usuario_perfil_datos_proyecto
					AND		d.dimension_proyecto=\'toba\'
					AND		d.dimension=\'solicitud_tipo\'
					ORDER BY 4,5,6; - [ERROR] ERROR:  ORDER BY position 5 is not in select list');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('205','2004-07-14 18:35:39','juan','bug','ZONA-OBJETO: NO se pudo cargar el editable , - [SQL]  	SELECT	o.*,
							o.subclase_archivo as 			archivo,
							c.icono as						clase_icono,
							c.editor_proyecto as			clase_editor_proyecto,
							c.editor_item as				clase_editor,
							c.instanciador_proyecto as		clase_instanciador_proyecto,
							c.instanciador_item as			clase_instanciador,
							c.archivo as					clase_archivo,
							c.plan_dump_objeto as 			clase_plan_sql,
							c.vinculos as					clase_vinculos,
							d.fuente_datos as				fuente,
							d.fuente_datos_motor as			fuente_motor,
							d.host as						fuente_host,
							d.usuario as					fuente_usuario,
							d.clave as						fuente_clave,
							d.base as						fuente_base,
							( SELECT count(*) 
								FROM apex_clase_dependencias cd 
								WHERE c.clase = cd.clase_consumidora 
								AND c.proyecto = cd.clase_consumidora_proyecto ) as clase_dep
					FROM	apex_objeto o,
							apex_fuente_datos d,
							apex_clase c
					WHERE	o.fuente_datos = d.fuente_datos
					AND		o.clase = c.clase
					AND		o.proyecto=\'toba\'
					AND		o.objeto=\'solicitud_tipo_r\' - [ERROR] ERROR:  pg_atoi: error in \"solicitud_tipo_r\": can\'t parse \"solicitud_tipo_r\"
');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('206','2004-07-14 18:53:40','juan','falta','SOLICITUD: El item solicitado no EXISTE!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('207','2004-07-15 03:42:43','juan','falta','SOLICITUD: El item solicitado no EXISTE!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('208','2004-07-15 03:42:52','juan','falta','SOLICITUD: El item solicitado no EXISTE!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('209','2004-07-15 03:42:54','juan','falta','SOLICITUD: El item solicitado no EXISTE!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('210','2004-07-15 03:43:00','juan','falta','SOLICITUD: El item solicitado no EXISTE!');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('211','2004-07-15 04:01:59','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 9 -- SQL: SELECT  as clave, 
 r. as descripcion, 
  as seteado 
 FROM  r
 LEFT OUTER JOIN  a
 ON 
 AND () 
  WHERE (r.proyecto = \'toba\')  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('212','2004-07-15 04:04:08','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 9 -- SQL: SELECT  as clave, 
 r. as descripcion, 
  as seteado 
 FROM  r
 LEFT OUTER JOIN  a
 ON 
 AND () 
  WHERE (r.proyecto = \'toba\')  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('213','2004-07-15 04:04:18','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 9 -- SQL: SELECT  as clave, 
 r. as descripcion, 
  as seteado 
 FROM  r
 LEFT OUTER JOIN  a
 ON 
 AND () 
  WHERE (r.proyecto = \'toba\')  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('214','2004-07-15 04:04:23','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 9 -- SQL: SELECT  as clave, 
 r. as descripcion, 
  as seteado 
 FROM  r
 LEFT OUTER JOIN  a
 ON 
 AND () 
  WHERE (r.proyecto = \'toba\')  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('215','2004-07-15 04:33:13','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 9 -- SQL: SELECT  as clave, 
 r. as descripcion, 
  as seteado 
 FROM  r
 LEFT OUTER JOIN  a
 ON 
 AND ((a.u= \'toba\') AND (a.s= \'perfil_x\')) 
  WHERE (r.proyecto = \'toba\')  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('216','2004-07-15 04:38:27','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 40 -- SQL: SELECT r.solicitud_tipo as clave, 
 r. as descripcion, 
 a.solicitud_tipo as seteado 
 FROM  r
 LEFT OUTER JOIN apex_dim_restric_soltipo a
 ON (r.solicitud_tipo = a.solicitud_tipo)
 AND ((a.proyecto= \'toba\') AND (a.usuario_perfil_datos= \'perfil_x\')) 
  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('217','2004-07-15 04:38:58','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"as\" at character 40 -- SQL: SELECT r.solicitud_tipo as clave, 
 r. as descripcion, 
 a.solicitud_tipo as seteado 
 FROM apex_solicitud_tipo r
 LEFT OUTER JOIN apex_dim_restric_soltipo a
 ON (r.solicitud_tipo = a.solicitud_tipo)
 AND ((a.proyecto= \'toba\') AND (a.usuario_perfil_datos= \'perfil_x\')) 
  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('218','2004-07-15 04:39:46','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  column a.proyecto does not exist -- SQL: SELECT r.solicitud_tipo as clave, 
 r.descripcion_corta as descripcion, 
 a.solicitud_tipo as seteado 
 FROM apex_solicitud_tipo r
 LEFT OUTER JOIN apex_dim_restric_soltipo a
 ON (r.solicitud_tipo = a.solicitud_tipo)
 AND ((a.proyecto= \'toba\') AND (a.usuario_perfil_datos= \'perfil_x\')) 
  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('219','2004-07-15 04:41:09','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  column a.proyecto does not exist -- SQL: SELECT r.solicitud_tipo as clave, 
 r.descripcion_corta as descripcion, 
 a.solicitud_tipo as seteado 
 FROM apex_solicitud_tipo r
 LEFT OUTER JOIN apex_dim_restric_soltipo a
 ON (r.solicitud_tipo = a.solicitud_tipo)
 AND ((a.proyecto= \'toba\') AND (a.usuario_perfil_datos= \'perfil_x\')) 
  ; -- ');
INSERT INTO apex_log_sistema (log_sistema, momento, usuario, log_sistema_tipo, observaciones) VALUES ('220','2004-07-15 04:54:25','juan','bug','OBJETO TABLA ASOCIACION: No se genero el recordset. -- ERROR:  syntax error at or near \"\\\" at character 339 -- SQL: SELECT r.solicitud_tipo as clave, 
 r.descripcion_corta as descripcion, 
 a.solicitud_tipo as seteado 
 FROM apex_solicitud_tipo r
 LEFT OUTER JOIN apex_dim_restric_soltipo a
 ON (r.solicitud_tipo = a.solicitud_tipo)
 AND ((a.usuario_perfil_datos_proyecto= \'toba\') AND (a.usuario_perfil_datos= \'perfil_x\')) 
  WHERE ((r.solicitud_tipo <> \\\'fantasma\\\'))  ; -- ');

-----------  apex_log_error_login  ------------------------

INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('1','2004-07-06 15:22:41','gfdsgfd','gfdgfdg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('2','2004-07-06 15:22:43','sgfdg','fdgfd','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('3','2004-07-06 16:09:36','sdfgfd','gfdsg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('4','2004-07-06 16:09:40','sgfd','gfdsg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('5','2004-07-06 16:09:42','gsd','gsd','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('6','2004-07-06 16:09:44','fdsgf','sdfg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('7','2004-07-06 16:09:45','sfdg','gsdfg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('8','2004-07-06 16:09:47','sdfg','sfdg','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('9','2004-07-06 16:09:49','gsfd','gfds','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('10','2004-07-06 16:09:51','sg','sdgs','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('11','2004-07-06 16:09:53','gfdsgd','gfds','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);
INSERT INTO apex_log_error_login (log_error_login, momento, usuario, clave, ip, gravedad, mensaje, punto_acceso) VALUES ('12','2004-07-06 16:09:55','dsfgsdf','gfds','168.83.60.212','1','La combinaci�n usuario/clave es incorrecta.',NULL);

-----------  apex_log_ip_rechazada  ------------------------

INSERT INTO apex_log_ip_rechazada (ip, momento) VALUES ('168.83.60.202','2004-07-06 16:09:55');
INSERT INTO apex_log_ip_rechazada (ip, momento) VALUES ('231.123.123.212','2004-07-12 12:25:36');
